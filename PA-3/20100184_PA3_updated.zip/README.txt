First run the PA3.py file from any directory. It doesnt take any command line arguments
Run Node.py from any directory. It take 2 command line arguments. The first is the port number. The second is the size of the hash table (i have only tested it with size 1024)
Use the client.py file to give a node a file. It takes 1 command line argument which is a port.
Use the client2.py file to download a file into the directory it is run from. It takes one command line argument which is its port.